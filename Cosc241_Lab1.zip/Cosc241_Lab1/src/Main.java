

public class Main {

/**
* @param args the command line arguments
*/
	public static void main(String[] args) {
		// Date Program
//		Date d=new Date(9, 3);
//		System.out.println(d.daysTillXmas());
//		  
//		Date d2=new Date(9,19);
//		d2.subtractWeeks(1);
//		d2.subtractWeeks(2);
//		d2.subtractWeeks(5);
//		d2.subtractWeeks(20);
//		d2.subtractWeeks(110);
//		System.out.println(d2);
		
		
		GroceryItemOrder test = new GroceryItemOrder("apple", 10, 2.00);
		GroceryItemOrder test3 = new GroceryItemOrder("apple", 1, 100.00);
		GroceryList test2 = new GroceryList();
		test2.add(test);
		test2.add(test3);
		System.out.println(test2.getTotalCost());
	}
  
}