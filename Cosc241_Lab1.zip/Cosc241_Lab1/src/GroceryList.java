
public class GroceryList {

    private GroceryItemOrder [] items;
    int itemCount;
   
    public GroceryList() {
        itemCount = 0;
        items = new GroceryItemOrder[10];
    }
    
    public void add ( GroceryItemOrder item) {
        items[itemCount] = item;
        itemCount++;
    }
    
    public double getTotalCost() {
        double totalCost = 0;
        for (int i=0; i<itemCount; i++) {
            totalCost += items[i].getCost();
        }
        return totalCost;
    }
} 
