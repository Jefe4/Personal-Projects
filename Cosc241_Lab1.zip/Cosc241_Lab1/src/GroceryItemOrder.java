public class GroceryItemOrder {
	
    double quantity;
    String name;
    double pricePerUnit;
    
    public GroceryItemOrder( String name , int quantity , double pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
        this.name = name;
        this.quantity = quantity;
    }
    
    public double getCost () {
        return pricePerUnit*quantity;
    }
    
    public void setQuantity ( int quantity ) {
        this.quantity = quantity;
    }
}