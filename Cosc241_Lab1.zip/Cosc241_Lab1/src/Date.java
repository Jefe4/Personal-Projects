public class Date {
	private int Month;
	private int Day;
	private static String MonthsName[]={"January","February","March","April","May","June","July","August","Septmber","October","November","December"};
	private static int MonthDays[]={31,28,31,30,31,30,31,31,30,31,30,31};
	
	public Date(int m,int d) {
		this.Month=m;
		this.Day=d;
	}
	
	public int getMonth() {
		return Month;
	}
	
	public int getDay() {
		return Day;
	}
	  
	public int daysInMonth() {
		return MonthDays[Month-1];
	}
	public void nextDay() {
		if(Month==2 && Day==28)
		{
			Day=1;
			Month=3;
			return ;
		}
		else if((Month==1 || Month==3 || Month==5 || Month==7 || Month==8 || Month==10 || Month==12) && Day==31 )
		{
		if(Month==12)
			Month=1;
		else
			Month+=1;
		Day=1;
		return ;
		}
		Day++;
	}
	public String toString()
	{
	return Month+"/"+Day;
	}
	  
	public int daysTillXmas()
	{
	int totalDays=0;
	for(int i= this.Month;i<11;i++)
	totalDays+=MonthDays[i];
	totalDays+=MonthDays[Month-1]-Day;
	totalDays+=25;
	return totalDays;
	}
	  
	public void subtractWeeks(int n)
	{
	int totalDays=0;
	for(int i=0;i<Month-1;i++)
	totalDays+=MonthDays[i];
	totalDays+=Day;
	  
	int subtractDays=n*7;
	int remainDays=totalDays-subtractDays;
	  
	int tempMonth=1,tempDay=0;
	int i=0;
	if(remainDays>0)
	{
	while(remainDays>MonthDays[i])
	{
	remainDays-=MonthDays[i];
	tempMonth++;
	i++;
	}
	tempDay=remainDays;
	}
	else
	{
	remainDays=-1*(remainDays%365);
	remainDays=365-remainDays;
	while(remainDays>MonthDays[i])
	{
	remainDays-=MonthDays[i];
	tempMonth++;
	i++;
	}
	tempDay=remainDays;
	}
	Month=tempMonth;
	Day=tempDay;
	}
	
	public static String[] getMonthsName() {
		return MonthsName;
	}
	
	public static void setMonthsName(String monthsName[]) {
		MonthsName = monthsName;
	}
}

