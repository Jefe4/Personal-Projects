import java.util.Scanner;

/*  COSC 241
    Due Date: 2/11/2021
    Your Name: Jeffrey Gomez
    Purpose of the program: Input a price of an item and sales tax rate then display price with calculated amount
*/

public class Program_1
{

    public static void main(String[] args)
    {
        Scanner myObj = new Scanner(System.in);
        System.out.println("Enter your name: ");
        String userName = myObj.nextLine();
        System.out.println("Hello"+ userName+"how was your day today?");

        System.out.println("Enter item 1");
        float item1 = myObj.nextFloat();
        System.out.println("Enter item 2");
        float item2 = myObj.nextFloat();
        System.out.println("Enter item 3");
        float item3 = myObj.nextFloat();
        System.out.println("Enter item 4");
        float item4 = myObj.nextFloat();
        System.out.println("Enter item 5");
        float item5 = myObj.nextFloat();

    double TAX_RATE = .06;
    double price;
    double tax;
    double total;

    tax = price * TAX_RATE;
    total = price + tax;
    System.out.println("Purchased: " + item1+item2+item3+item4+item5+price);
    System.out.println("Tax is"+tax);
    System.out.println("Total is"+total);

    }



}
