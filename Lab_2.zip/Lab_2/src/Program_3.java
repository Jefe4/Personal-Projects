/*  COSC 241
    Due Date: 2/11/2021
    Your Name: Jeffrey Gomez
    Purpose of the program: To find the sum, difference, product and quotient of two integers.
*/

import java.util.Scanner
public class Program_3
{
    public static void main(String [] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Input the first number: ");
        int num1 = in.nextInt();
        System.out.print("Input the second number: ");
        int num2 = in.nextInt();

        System.out.println("Sum is :"(num1 + num2) );
        System.out.println("Difference is:" (num1 - num2) );
        System.out.println("Product is:" (num1 * num2) );
        System.out.println("Quotient is:" (num1 / num2) );



    }




}
