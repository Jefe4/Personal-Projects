/*  COSC 241
    Due Date: 2/11/2021
    Your Name: Jeffrey Gomez
    Purpose of the program: Find the average between three test scores
*/


import java.util.Scanner;

public class Program_2
{


    public static void main(String [] args)
        Scanner Num1 = new Scanner(System.in);
        System.out.println("Enter first Test score: ")
        double num1 = Num1.nextDouble();
        System.out.println("Enter second Test Score: ")
        double num2 = Num1.nextDouble();
        System.out.println("Enter third Test Score: ")
        double num3 = Num1.nextDouble();

        double total = num1+num2+num3;
        double average = (num1+num2+num3=total / 3);
        System.out.println(num1+num2+num3 = total)
        System.out.println("The average is "+ average(num1+num2+num3=total / 3))



}
